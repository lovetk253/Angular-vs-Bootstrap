package com.minato.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentNumber1RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentNumber1RestApplication.class, args);
	}
}
